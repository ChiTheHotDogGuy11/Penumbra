/***************
**GLOBALS ******
* The following are the globals used throughout the remaining files.
* They are collected in one place to make it easier to follow what's going on.
****************/

/* Summary: The setInterval instantiation of updating the avaliable parties
 * Locations used: this file, joinPartyPage.js */
var OPEN_PARTIES_INST;

/* Summary: The time (in milliseconds) to wait before the avaliable aprty list gets updated 
 * Locations used: this file */
var OPEN_PARTY_INTERVAL = 4000;

/* Summary: Keep track of the last party highlighted so the info isn't losed every
 *		time the party list is updated.
 * Locations used: this file, joinPartyPage.js */
var LAST_PARTY_HIGHLIGHTED = {
	id: -1,
	name: "" };
	
/* Summary: The border that jQuery mobile applies to text inputs.
 * Locations used: this file, joinPartyPage.js */
var INPUT_BORDER;

/* Summary: The id of the party the user joins
 * Locations used: joinPartyPage.js, partyPage.js */
var PARTY_ID;

/* Summary: The setInterval instantiation of updating the playlist
 * Locations used: joinPartyPage.js, partyPage.js */
var UPDATE_PLAYLIST_INST;

/* Summary: Variable to describe if the playlist is being updated
 * Locations used: partyPage.js, addTrackPage.js */
var PLAYLIST_UPDATING = false;

/* Summary: The time (in milliseconds) to wait before the playlist gets updated 
 * Locations used: this file */
var UPDATE_PLAYLIST_INTERVAL = 4000;

/* Summary: The height of the divs that contain tracks
 * Locations used: partyPage.js */
var TRACK_HEIGHT = 200;

/* Summary: The height of the divs when they're not expanded.
 * Locations used: partyPage.js */
var SMALL_TRACK_HEIGHT = .38 * TRACK_HEIGHT;

/* Summary: The partier id when a user first registers for a party
 * Locations used: joinPartyPage.js, partyPage.js, addTrackPage.js */
var PARTIER_ID = -1;

/* Summary: An array containing all of the HTML track objects, which essentially
 *		acts as a cache when we update the playlist 
 * Locations used: partyPage.js */
var TRACK_ARRAY = [];

/* Summary: The number of tracks to display when we try to add a song 
 * Locations used: addTrackPage.js */
var NUM_TRACKS_TO_DISPLAY = 5;

/* Summary: Information about the currently-highlighted track on add song
 * Locations used: registrationPage.js */
var SELECTED_TRACK = {
	uri: "",
	name: "",
	artist: "",
	album: ""
}

/***************
**BINDINGS *****
***************/

/* 
 * Summary: Function that gets called when everything is loaded. It essentially
		just binds all the proper functions to input events.
 * Parameters: None
 * Returns: Undefined
*/

$(document).ready(function() {   
	//first we want to wait for PhoneGap to load
	document.addEventListener("deviceready", loaded, false);
});

function loaded() {
	INPUT_BORDER = $("#someText").css("border");
	//When a party is tapped, make it the active party
	$(".openParty").live("tap", function() {
		$(".openParty").removeClass("currentParty");
		$(this).addClass("currentParty");
		//Make sure we refresh the highlighted party when list gets updated
		LAST_PARTY_HIGHLIGHTED = {
			id: this.ID,
			name: this.name};
	});
	
	$("#trackName").live("blur", function() {
		//This function strangelu gets called when #someText gets blurred as well
		if (PARTIER_ID !== -1) {
			updateSongSuggestions($("#trackName").val());
		}
	});
	
	//Need to override weird jquery_mobile reaction to pressing enter in a text field
	//Also, error check
	$(document).keypress(function(e) {
		window.scrollTo(0, 0);
		document.body.scrollTop = 0;
		if (e.which == 13) {
			e.preventDefault();
			if ($("#someText").val() === "") {
				$("#someText").css("border", "3px solid red");
			}
			else {
				$("#someText").css("border", INPUT_BORDER);
			}
			$("#someText").blur();
			$("#trackName").blur();
		}
	});
	
	//When the user clicks a track, expand it and stuff.
	//I had to define it here because I had trouble percolating the event target
	/* Summary: If the track is expanded, restract it and vice-versa. Do a little animation.
	 * Parameters: event: object containing details of the tap event
	 * Returns: undefined
	*/
	$(".track").live("tap", function() {	
		//Animation duration in milliseconds
		var animationLength = 350;
		if (($(this).data("isExpanded") && !$(this).data("hasVoted")) || ($(this).data("isExpanded") && $(this).hasClass("nowPlaying"))) {
			//$(this).css("maxHeight", .75 * TRACK_HEIGHT + "px");
			$(this).animate({maxHeight:SMALL_TRACK_HEIGHT + "px"}, animationLength);
			$(this).data("isExpanded", false);
		}
		else if (!$(this).data("isExpanded") && !$(this).data("hasVoted") && !$(this).hasClass("nowPlaying")){
			//$(this).css("maxHeight", TRACK_HEIGHT + "px");
			$(this).animate({maxHeight: TRACK_HEIGHT + "px"}, animationLength);
			$(this).data("isExpanded", true);
		}
		//Refresh the scroller to display the new content
		$(".iscroll-wrapper").jqmData("iscrollview").refresh();
	});
	
	/* React when the user tries to for for a track */
	$(".voteFor").live("tap", function() {
		//Animation duration in milliseconds
		var animationLength = 350;
		//The container div (i.e. the track div) 
		var $parent = $(this).closest("li");
		$parent.data("hasVoted", true);
		/* Update the number of votes displayed */
		var curVotes = $parent.children(".topTrackVoteCount").children(".vote_num").html();
		$parent.children(".topTrackVoteCount").children(".vote_num").html(parseInt(curVotes) + 1);
		//Convey to the user that they've already voted for this track
		$parent.children(".ballotPic").css("background-color", "rgb(0, 181, 19)");
		//Permanently prevent the track from expanding
		$parent.animate({height:SMALL_TRACK_HEIGHT + "px"}, animationLength);
		//Refresh the scroller to display the new content
		$(".iscroll-wrapper").jqmData("iscrollview").refresh();
		//Now actually cast the vote to the database
		castVote($parent.data("ID"), true);
	});
	
	/* React when the user tries to vote against a track */
	$(".voteAgainst").live("tap", function() {
		//Animation duration in milliseconds
		var animationLength = 350;
		var $parent = $(this).closest("li");
		$parent.data("hasVoted", true);
		/* Update the number of votes displayed */
		var curVotes = $parent.children(".topTrackVoteCount").children(".vote_num").html();
		$parent.children(".topTrackVoteCount").children(".vote_num").html(parseInt(curVotes) - 1);
		//Convey to the user that they've already voted for this track
		$parent.children(".ballotPic").css("background-color", "rgb(200, 35, 0)");
		//Permanently prevent the track from expanding
		$parent.animate({height:SMALL_TRACK_HEIGHT + "px"}, animationLength);
		//Refresh the scroller to display the new content
		$(".iscroll-wrapper").jqmData("iscrollview").refresh();
		//Now actually cast the vote to the database
		castVote($parent.data("ID"), false);
	});
	
	/* When a track in the add track list is selected, make it active 
	 * Need to use live because they're added asynchronously*/
	$(".addTrack").live("tap", function() {
		$(".addTrack").removeClass("selectedTrack");
		$(this).addClass("selectedTrack");
		SELECTED_TRACK.uri = this.uri;
		SELECTED_TRACK.name = this.trackName;
		SELECTED_TRACK.album = this.albumName;
		SELECTED_TRACK.artist = this.artistName;
	});
	
	//When the submit button is clicked, validate then join the party
	$("#joinButton").live("tap", function() {
		$('button').removeClass('ui-btn-active');
		$(this).addClass("ui-btn-active");
		validateThenSubmit();
	});
	
	//When the user tries to add a track, validate it then add it to the playlist
	$("#addTrackButton").live("tap", function() {
		$('button').removeClass('ui-btn-active');
		$(this).addClass("ui-btn-active");
		validateThenSubmitNewTrack();
	});
	
	//Needed to stop weird stuff from happening
	$("#submitSong a").live("tap", function() {
		if (PLAYLIST_UPDATING) {
			clearInterval(UPDATE_PLAYLIST_INST);
			PLAYLIST_UPDATING = false;
		}
	});
	
	//Initially, show a list of the avaliable parties
	updateOpenParties();
	
	//Periodically update the avaliable parties
	OPEN_PARTIES_INST = setInterval(function(){updateOpenParties()}, OPEN_PARTY_INTERVAL);
}