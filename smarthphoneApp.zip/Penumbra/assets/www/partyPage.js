/*
 * Summary: Submit a new ajax request to the server to update the playlist
 * Parameters: None
 * Returns: undefined
*/
function updatePlaylistRequest() {
	$.ajax({
		url: "http://www.justingreet.com/penumbra/readUpdatePlaylist.php",
		type: "get",
		data: {playlistPartyID: PARTY_ID},
		dataType: "xml", 
		success: function(response, textStatus) {
			updatePlaylistXMLResponse(response);
		},
		error: function(jqXHR, textStatus, errorThrown){
			//Don't do anything on errors, because they'll probably happen occasionally.
			//They're not critical failures on playlist updates.
		}
	});
}

/*
 * Summary: parse the XML response from the ajax request to update the playlist.
 *		Namely, update the divs that are displayed for each track.
 * Parameters: xmlDoc: the xml response to parse
 * Returns: undefined
 * XML Structure:
		<Playlist>
			<Track>
				<ID>$value</ID>
				<Name>$value</Name>
				<Votes_for>$value</VotesFor>
				<Artist>$value</Artist>
				<Album>$value</Album>
				<Currently_playing>$value</CurrentlyPlaying>
			</Track>
		</Playlist>
*/
function updatePlaylistXMLResponse(xmlDoc) {
	var songCount = $(xmlDoc).find("Track").length; 
	var divHeight = TRACK_HEIGHT;
	var divWidth = $("#playlistContainer").width();
	var ballotWidth = 30;

	/* Reset the playlist every time it's updated */
	$("#loadingPlaylist").remove();
	$(".track").remove();
	$(".bottom_buffer").remove();
	$(".nowPlaying").remove();
	var counter = 0;
	
	$(xmlDoc).find("Track").each(function() {
		var newTrack;
		var trackID = $(this).find("ID").text();
		var arrayMatch = isTrackInArray(trackID);
		/* If the track already exists in the playlist, just set them to be equal */
		if (arrayMatch.match) {
			newTrack = arrayMatch.matchingObject;
			newTrack.ID = trackID;
			$(newTrack).data("ID", trackID);
			if (counter === 0) {
				$(newTrack).children(".topTrackVoteCount").children(".vote_num").html("");
				$(newTrack).addClass("nowPlaying");
			}
			else {
				$(newTrack).children(".topTrackVoteCount").children(".vote_num").html($(this).find("Votes_for").text());
			}
			$(newTrack).css("display", "block");
		}
		/* Otherwise, we need to make an entirely new track. */
		else {
			/* new track setup */
			newTrack = document.createElement("li");
			newTrack.ID = trackID;
			$(newTrack).data("ID", trackID);
			$(newTrack).height(divHeight);
			$(newTrack).width(divWidth);
			$(newTrack).addClass("track");
			$(newTrack).css("max-height", SMALL_TRACK_HEIGHT + "px");
			/* setup the number of votes the track has */
			var trackCounter = document.createElement("div");
			$(trackCounter).addClass("topTrackVoteCount");
			var trackCounterText = document.createElement("h1");
			if (counter === 0) {
				$(trackCounterText).html("");
				$(newTrack).addClass("nowPlaying");
			}
			else {
				$(trackCounterText).html($(this).find("Votes_for").text());
			}
			$(trackCounterText).addClass("vote_num");
			$(trackCounter).append(trackCounterText);
			/* setup the div that holds the track name and artist */
			var infoDiv = document.createElement("div");
			$(infoDiv).addClass("infoDiv");
			var trackInfo = document.createElement("p");
			$(trackInfo).addClass("trackInfo");
			$(trackInfo).html($(this).find("Name").text() + "<br/><span class=\"artistName\">by " + $(this).find("Artist").text() + "</span>");
			$(infoDiv).append(trackInfo);
			/* Make space for the graphic to show they've already voted for the track */
			var ballotPic = document.createElement("div");
			$(ballotPic).addClass("ballotPic");
			$(ballotPic).width(ballotWidth);
			var ballotXPos = divWidth - ballotWidth;
			$(ballotPic).css("left", ballotXPos + "px");
			$(ballotPic).height(SMALL_TRACK_HEIGHT);
			/* Constants accross both kinds of votes */
			var voteHeight = .85 * TRACK_HEIGHT - SMALL_TRACK_HEIGHT;
			var infoLeft = ($(newTrack).width()) * .15;
			var containerWidth = $("#playlistContainer").width() - infoLeft;
			var voteWidth = .22 * containerWidth;
			var voteGap = .15 * containerWidth;
			var voteTop = SMALL_TRACK_HEIGHT + (((TRACK_HEIGHT - SMALL_TRACK_HEIGHT) - voteHeight)/2);
			/* The div to vote for a track */
			var voteFor = document.createElement("div");
			$(voteFor).addClass("voteFor");
			$(voteFor).height(voteHeight);
			$(voteFor).width(voteWidth);
			$(voteFor).css("top", voteTop + "px");
			var forLeft = infoLeft + ((containerWidth - (2*voteWidth + voteGap))/2);
			$(voteFor).css("left", forLeft + "px");
			/* The div to vote against a track */
			var voteAgainst = document.createElement("div");
			$(voteAgainst).addClass("voteAgainst");
			$(voteAgainst).height(voteHeight);
			$(voteAgainst).width(voteWidth);
			$(voteAgainst).css("top", voteTop + "px");
			$(voteAgainst).css("left", forLeft + voteWidth + voteGap + "px");
			/* bring all the elements together */
			$(newTrack).append(trackCounter);
			$(newTrack).append(infoDiv);
			$(newTrack).append(ballotPic);
			$(newTrack).append(voteFor);
			$(newTrack).append(voteAgainst);
			$(infoDiv).css("left", infoLeft + "px");
			TRACK_ARRAY.push(newTrack);
		}
		$("#playlistContainer ul").append(newTrack);
		//Adjust the font-size of the track name and artist
		adjustFontSize(infoDiv, trackInfo);
		counter += 1;
	});
	//Add an extra blank div to the bottom to make scrolling work properly
	var bottomDiv = document.createElement("div");
	$(bottomDiv).height(SMALL_TRACK_HEIGHT);
	$(bottomDiv).width(divWidth);
	$(bottomDiv).addClass("bottom_buffer");
	$("#playlistContainer ul").append(bottomDiv);
	//Refresh the scroller to display the new content
	$(".iscroll-wrapper").jqmData("iscrollview").refresh();
}

/*
 * Summary: adjust the size of the track name and artist name to ensure they both fit in the allocated div
 * Parameters: infoDiv: The div that contains the track information
			   trackInfo: The actual text that details the track name and track artist
			   ballotWidth: The width of the picture at the end of the track when the user has voted
 * Returns: undefined
*/
function adjustFontSize(infoDiv, trackInfo, ballotWidth) {
	//A quick hack to probably force the artist name to fit on a single line
	var artistNameText = $(trackInfo).children(".artistName").text();
	if (artistNameText.length > 30) $(trackInfo).children(".artistName").css("font-size", 19);
	
	/* Now we worry about the size of the track name, in a more robust fashion */
	//Font size in pixels 
	var fontSize = 33;
	//Height of the artist name
	var artistHeight = $(trackInfo).children(".artistName").height();
	//Make the max height of the track name the size of the div minus the height of the artist name
	var maxHeight = $(infoDiv).height() * (.9)- artistHeight;
	var maxWidth = $(infoDiv).width();
	var textHeight;
	var textWidth;
	/* Reduce the size of the font as long as it doesn't fit the maxHeight and maxWidth constraints */
	do {
		$(trackInfo).css("font-size", fontSize);
		textHeight = $(trackInfo).height() - artistHeight;
		textWidth = $(trackInfo).width();
		fontSize = fontSize - 1;
	} while ((textHeight > maxHeight) || (textWidth > maxWidth));
}

/* 
 * Summary: Check if a track is already in the track array 
 * Parameters: trackID: The ID of the track to check for
 * Returns: true and the object matched if the track exists, false otherwise
*/
function isTrackInArray(trackID) {
	var result = {
		match: false,
		matchingObject: "" };
	var curTrackID;
	for (var i = 0; i < TRACK_ARRAY.length; i++) {
		curTrackID = TRACK_ARRAY[i].ID;
		if (curTrackID === trackID) {
			result.match = true;
			result.matchingObject = TRACK_ARRAY[i];
			return result;
		}
	}
	result.match = false;
	return result;
}

/*
 * Summary: Cast a vote for a song (can only cast it once!)
 * Parameters: trackIDer: The ID of the track to vote for
 * 				isVoteFor: true if the vote is for the track, false otherwise
 * Returns: undefined
*/
function castVote(trackIDer, isVoteFor) {
	$.ajax({
		url: "http://www.justingreet.com/penumbra/submitVote.php",
		type: "post",
		data: {partyID: PARTY_ID, partierID: PARTIER_ID, trackID: trackIDer, voteFor: isVoteFor},
		dataType: "text", 
		success: function(response, textStatus) {
			//Don't do anything after vote is cast
		},
		error: function(jqXHR, textStatus, errorThrown){
			alert("Error: Couldn't vote for track");
		}
	});
}