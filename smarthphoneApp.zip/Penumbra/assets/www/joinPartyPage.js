/*
 * Summary: While the user is in the process of joining a party, periodically update the 
 *		list of avaliable parties to stay up-to-date
 * Parameters: None
 * Returns: undefined
*/
function updateOpenParties() {
	$.ajax({
		url: "http://www.justingreet.com/penumbra/readUpdateParties.php",
		type: "get",
		dataType: "xml", 
		success: function(response, textStatus) {
			updatePartiesXMLResponse(response);	
		},
		error: function(jqXHR, textStatus, errorThrown){
		}
	});
}

/*
 * Summary: parse the XML response from the ajax request to update the list of
  *		available parties.
 * Parameters: xmlDoc: the xml response to parse
 * Returns: undefined
 * XML structure: 
 	<Parties>
		<Party>
			<ID>$value</ID>
			<Name>$value</Name>
		</Party>
 	</Parties>
*/
function updatePartiesXMLResponse(xmlDoc) {
	$(".openParty").remove();
	$(xmlDoc).find("Party").each(function(){
		//Create the div to store the party info
		var newParty = document.createElement("li");
		$(newParty).addClass("openParty");
		newParty.name = $(this).find("Name").text();
		$(newParty).html(newParty.name);
		newParty.ID = $(this).find("ID").text();
		//Carry over the highlight from before the db call
		if (newParty.ID === LAST_PARTY_HIGHLIGHTED.id) $(newParty).addClass("currentParty");
		$("#openPartyContainer ul").append(newParty);
		//$(".iscroll-content").append(newParty);
	});
	//Remove the bottom-border from the last element, so it doesn't look clunky
	$("#openPartyContainer ul li").last().css("border-bottom", "none");
	//Refresh the scroller to display the new content
	//$(".iscroll-wrapper").jqmData("iscrollview").refresh();
}

/*
 * Summary: Checks to see if the partier has a name and party is selected.
 *		If both of these requirements are met, it sends an ajax request to join the party.
 *		Otherwise, it highlights both input texts with red to indicate an error.
 * Parameters: None
 * Returns: undefined
*/
function validateThenSubmit() {
	if (LAST_PARTY_HIGHLIGHTED.name === "") {
		$("#openPartyContainer").css("border", "3px solid red");
	}
	else $("#openPartyContainer").css("border", "1px solid black");
	
	var curPartierName = $("#someText").val();
	if (curPartierName === "") {
		$("#someText").css("border", "3px solid red");
	}
	else $("#someText").css("border", INPUT_BORDER);
	
	if (LAST_PARTY_HIGHLIGHTED.name !== "" && curPartierName !== "") {
		//Now we know the party id
		PARTY_ID = LAST_PARTY_HIGHLIGHTED.id;
		/* Change the scale of the page to make jquery_mobile appear more crisp.
		 * Couldn't do on the previous page because it prevents the keyboard from appearing. */
		var viewport = document.querySelector("meta[name=viewport]");
		viewport.setAttribute('content', 'width=device-width, target-densitydpi=device-dpi, minimum-scale=1, maximum-scale=1;');
		//change the page to the party page
		$.mobile.changePage( $("#partyPage"));
		//Make sure the avaliable parties stop updating
		clearInterval(OPEN_PARTIES_INST);
		//Make the ajax request to join the party
		//After this point, the javascript is located in partyPage.js
		$.ajax({
		url: "http://www.justingreet.com/penumbra/submitNewPartier.php",
		type: "post",
		data: {newPartierName: curPartierName, partyToJoinID: PARTY_ID},
		dataType: "xml", 
		/* XML Structure
			<Partier>
				<ID>$value</ID>
				<Name>$value</Name>
			</Partier>
		*/
		success: function(response, textStatus) {
			//Get the partier id
			$(response).find("Partier").each(function () {
				PARTIER_ID = parseInt($(this).find("ID").text());
			});
			if (!PLAYLIST_UPDATING) {
				/* Start updating the playlist periodically */
				UPDATE_PLAYLIST_INST = setInterval(function(){updatePlaylistRequest()}, UPDATE_PLAYLIST_INTERVAL);
				PLAYLIST_UPDATING = true;;
			}
			//updatePlaylistRequest();
		},
		error: function(jqXHR, textStatus, errorThrown){
			alert("CRAP");
		}
	});
	}
}