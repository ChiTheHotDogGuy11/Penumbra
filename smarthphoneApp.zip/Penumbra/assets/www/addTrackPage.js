/*
 * Summary: Update the songs to be added to the playlist based on the input
 *		provided by the user.
 * Parameters: trackName: The input string to update based on
 * Returns: undefined
*/
function updateSongSuggestions(trackName) {
	$.ajax({
		url: 'http://ws.spotify.com/search/1/track',    
		type: 'GET',    
		dataType: 'xml',       
		data: {    
			q: trackName,        
		},    
		success: function(response, textStatus) {
			parseTracks(response);
		},
		error: function(xhr, status, errorThrown) {    
			alert("networking error: "+errorThrown+'\n'+status+'\n'+xhr.statusText);    
		}
	});
}

function parseTracks(xmlDoc) {
	//Reset the selected track
	SELECTED_TRACK.uri = "";
	//Clear the track display to make way for the new one.
	$(".addTrack").remove();
	//Keep track of how many tracks we've seen
	var counter = 0;
	//Get the height that the div for each track should be
	var divHeight = $("#songSuggestions").height() / NUM_TRACKS_TO_DISPLAY;
	//Make a new div for each track to display, and append it to the track container.
	$(xmlDoc).find("track").each(function() {
		counter += 1;
		var curTrack = $(this);
		//Only keep iterating if there are tracks to process
		if (counter <= NUM_TRACKS_TO_DISPLAY) {
			/* Initialize the track (give it a height and add a class) */
			var newTrackDiv = document.createElement("div");
			$(newTrackDiv).height(divHeight);
			$(newTrackDiv).addClass("addTrack");
			//Alternate the color of the divs
			if (counter % 2 !== 0) $(newTrackDiv).addClass("oddTrack");
			/* make all of the components of the div */
			var nameCounter = 0;
			var trackName;
			//There are a lot of fields called name, so make sure we only check the first one!
			curTrack.find("name").each(function() {
				if (nameCounter === 0) trackName = $(this).text();
				nameCounter += 1;
			});
			newTrackDiv.trackName = trackName;
			//There could be multiple artists, so accommodate that
			var artistName;
			var artistCounter = 0;
			curTrack.find("artist").each(function() {
				if (artistCounter === 0) {
					artistName = $(this).find("name").text();
				}
				else {
					artistName += ", " + $(this).find("name").text();
				}
				artistCounter += 1;
			});
			newTrackDiv.artistName = artistName;
			//The string to display in each div (exclude the album)
			var paraString = trackName + " by " + artistName;
			var albumName = curTrack.find("album").find("name");
			newTrackDiv.albumName = albumName;
			var trackPara = document.createElement("p");
			$(trackPara).html(paraString);
			$(newTrackDiv).append(trackPara);
			newTrackDiv.uri = curTrack.attr("href");
			$("#songSuggestions").append(newTrackDiv);
		}
	});
}

function validateThenSubmitNewTrack() {
	if (SELECTED_TRACK.uri === "") {
		$("#trackName").css("border", "3px solid red");
	}
	else {
		$("#trackName").css("border", INPUT_BORDER);	
		//Change the page the user sees
		$.mobile.changePage($("#partyPage"));
		if (!PLAYLIST_UPDATING) {
			//Start updating the playlist again.
			UPDATE_PLAYLIST_INST = setInterval(function(){updatePlaylistRequest()}, UPDATE_PLAYLIST_INTERVAL);
			PLAYLIST_UPDATING = true;
		}
		//Submit the song addition to the database 
		submitNewTrackRequest();
	}
}

/*
 * Summary: Submit a new ajax request to the server to add the selected track to the playlist
 * Parameters: none
 * Returns: undefined
*/
function submitNewTrackRequest() {
	$.ajax({
		url: "http://www.justingreet.com/penumbra/submitNewTrack.php",
		type: "post",
		data: {partierToSubmit: PARTIER_ID, partyToSubmitTo: PARTY_ID, trackID: SELECTED_TRACK.uri, trackName: SELECTED_TRACK.name, trackArtist: SELECTED_TRACK.artist, trackAlbum: "times are best"},
		//data: {partierToSubmit: PARTIER_ID, partyToSubmitTo: PARTY_ID, trackID: SELECTED_TRACK.uri, trackName: SELECTED_TRACK.name, trackArtist: SELECTED_TRACK.artist, trackAlbum: SELECTED_TRACK.album},
		dataType: "text", 
		success: function(response, textStatus) {
			//Alert the user if they entered a track that's already on the playlist.
			if (response === "false") alert("Sorry, that track is already on the playlist!");
		},
		error: function(jqXHR, textStatus, errorThrown){
			alert("Could not submit new track. Please try again!");
		}
	});
}
	